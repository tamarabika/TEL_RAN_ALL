public enum Gender {
    MALE, WOMEN


}
