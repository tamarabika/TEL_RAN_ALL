public class Animals {
    String name;
    String city;
    int amount;
    Gender gender;

    int cage;


}